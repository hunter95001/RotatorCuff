﻿/****************************************
PROGRAMER:공영재
PROJECT: ROI
EXPLANATION: 

초음파 영상에서 환자의 개인정보를 제거하고 회전근개 영역을 표시한 눈금자만큼 영역을 추출한다.
     
넓이는 195와 900의 정적인 영역으로 추출이 가능하지만 눈금자의 크기는 사진 마다 다 다르다.
사진의 크기를 제기 위해서 눈금자의 위치와 크기를 제는 알고리즘을 제작해야함. 
        
Step #1 넓이는 195~900까지의 넓이를 추출함
Step #2 눈금의 위치는 902 위치 (일일이 확인함)
Step #3 눈금에서 눈금자를 찾는 역할을 합니다 
[눈금은 세로로 5이하의 점이 뭉쳐 있습니다]
[눈금자는 세로로 200이상의 점이 이어져 있습니다.]
****************************************/

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TEST
{
    class ROI
    {
        private Bitmap ROI_Bitmap;              // 비트맵 반환

        //넓이는 정적으로 할당 가능
        private const int LEFT_X = 195;
        private const int RIGHT_X = 900;

        //높이는 눈금자 크기 만큼 할당 해야 합니다.
        private int MAXhigh = 0;                // 눈금자의 최대 높이
        private int MINhigh = 9999;             // 눈금자의 최소 높이
        private int count = 0;                  // 회전근개 영역인지 확인하는 카운트
        private int maxcount = 0;               // 카운트 회수가 많으면 회전근개 영역으로 인지
        private int pasty = 0;                  //이전 높이를 담아 두는 변수값
        private bool sema = true;               //카운트 값이 최대면 더이상 MIN 값을 바꾸지 않기 위해서

        public void Run(Bitmap getbitmap)
        {
            MAXhigh = 705;
            MINhigh = 241;
            int high = (MAXhigh - MINhigh);                             // 높이는 최대- 최소 입니다.
            int width = RIGHT_X - LEFT_X;
            ROI_Bitmap = new Bitmap(width, high);                     // bitmap 크기가 달라졌기 때문에 새로 만들어 줘야 합니다.

            for (int x = 0; x < width; x++)
                for (int y = 0; y < high; y++)
                {
                    ROI_Bitmap.SetPixel(x, y, getbitmap.GetPixel(LEFT_X + x, MINhigh + y));
                }

        }

        /*
         눈금자로 짤랐을경우
             */
        private void preversiont(Bitmap getbitmap)
        {
            for (int x = 0; x < getbitmap.Width; x++)
                for (int y = 0; y < getbitmap.Height; y++)
                {
                    if (getbitmap.GetPixel(x, y).R > 250 && x == 902)   //902번 좌표에 눈금자가 있음
                    {
                        count++;
                        if (count == 1 && sema == true)                   //카운트가 1이면 눈금자가 시작하는 부분으로 인식
                        {
                            MINhigh = y;
                        }

                        if (maxcount < count)                          // 카운트 수가 많으면 많은 쪽으로 업데이트 시켜줍니다.
                        {
                            if (maxcount == 5)
                            {                        // 일반 눈금은 카운트 수가 5이상 넘지 않아 넘는 카운트는 
                                sema = false;                           // 회전근개 영역이라고 판단 합니다.
                            }

                            maxcount = count;
                            MAXhigh = y;
                        }
                        pasty = y;
                    }
                    else
                    {
                        if (pasty + 20 < y)                                // 각 눈금 사이의 간격이 20을 넘지 못합니다.
                        {
                            count = 0;
                        }
                    }
                }

            int high = (MAXhigh - MINhigh);                             // 높이는 최대- 최소 입니다.
            int width = RIGHT_X - LEFT_X;
            ROI_Bitmap = new Bitmap(width, high);                     // bitmap 크기가 달라졌기 때문에 새로 만들어 줘야 합니다.

            for (int x = 0; x < width; x++)
                for (int y = 0; y < high; y++)
                {
                    ROI_Bitmap.SetPixel(x, y, getbitmap.GetPixel(LEFT_X + x, MINhigh + y));
                }

        }

        public int getMAX()
        {
            return MAXhigh;
        }
        public int getMIN()
        {
            return MINhigh;
        }

        public Bitmap getBimap()
        {
            //비트맵의 크기가 1024,728 -> 695,550 으로 바뀌기 때문에 새로은 비트맵을 만들어서 리턴해줘야함
            return ROI_Bitmap;
        }

    }
}
